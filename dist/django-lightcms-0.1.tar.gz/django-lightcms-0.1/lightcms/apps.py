from django.apps import AppConfig


class LightcmsConfig(AppConfig):
    name = 'lightcms'
