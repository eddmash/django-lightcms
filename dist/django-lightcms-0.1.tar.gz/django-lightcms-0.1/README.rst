A Cms for Developers
====================

This a very basic cms to incoporate in your project.

The main reason for this to avoid those static page contents like about us, on the app.